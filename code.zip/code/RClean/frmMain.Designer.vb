﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cookies", -2, -2)
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Temporary Internet Files", -2, -2)
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("History", -2, -2)
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Recently Typed URLs", -2, -2)
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Index", -2, -2)
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Internet Explorer", 3, 3, New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4, TreeNode5})
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cookies")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cache")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Internet History")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Google Chrome", 1, 1, New System.Windows.Forms.TreeNode() {TreeNode7, TreeNode8, TreeNode9})
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cookies", 0, 0)
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Download History", 0, 0)
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Form History", 0, 0)
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cache", 0, 0)
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Session Store", 0, 0)
        Dim TreeNode16 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mozilla Firefox", 2, 2, New System.Windows.Forms.TreeNode() {TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15})
        Dim TreeNode17 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cache")
        Dim TreeNode18 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("History", 0, 0)
        Dim TreeNode19 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Webpage Previews", 0, 0)
        Dim TreeNode20 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Download History", 0, 0)
        Dim TreeNode21 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Last Session", 0, 0)
        Dim TreeNode22 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Safari", 4, 4, New System.Windows.Forms.TreeNode() {TreeNode17, TreeNode18, TreeNode19, TreeNode20, TreeNode21})
        Dim TreeNode23 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cache", 0, 0)
        Dim TreeNode24 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("History")
        Dim TreeNode25 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cookies", 0, 0)
        Dim TreeNode26 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Website Icons", 0, 0)
        Dim TreeNode27 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Download History", 0, 0)
        Dim TreeNode28 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Opera", 5, 5, New System.Windows.Forms.TreeNode() {TreeNode23, TreeNode24, TreeNode25, TreeNode26, TreeNode27})
        Dim TreeNode29 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Recent Documents", 0, 0)
        Dim TreeNode30 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Thumbnail Cache", 0, 0)
        Dim TreeNode31 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Windows Explorer", 6, 6, New System.Windows.Forms.TreeNode() {TreeNode29, TreeNode30})
        Dim TreeNode32 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Windows Temp Files")
        Dim TreeNode33 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("User Temp Files", 0, 0)
        Dim TreeNode34 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Memory Dumps", 0, 0)
        Dim TreeNode35 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ChkDsk File Fragments", 0, 0)
        Dim TreeNode36 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Windows Log Files", 0, 0)
        Dim TreeNode37 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Windows Error Reporting", 0, 0)
        Dim TreeNode38 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("System", New System.Windows.Forms.TreeNode() {TreeNode32, TreeNode33, TreeNode34, TreeNode35, TreeNode36, TreeNode37})
        Dim TreeNode39 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Prefetch Data", -2, -2)
        Dim TreeNode40 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Advanced", 8, 8, New System.Windows.Forms.TreeNode() {TreeNode39})
        Dim TreeNode41 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("uTorrent")
        Dim TreeNode42 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Java")
        Dim TreeNode43 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("FileZilla")
        Dim TreeNode44 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Internet Applications", 9, 9, New System.Windows.Forms.TreeNode() {TreeNode41, TreeNode42, TreeNode43})
        Dim TreeNode45 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Paint.NET", 0, 0)
        Dim TreeNode46 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Miscellaneous Applications", 10, 10, New System.Windows.Forms.TreeNode() {TreeNode45})
        Dim TreeNode47 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Windows Media Player")
        Dim TreeNode48 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Quick Time Player", 0, 0)
        Dim TreeNode49 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Adobe Flash Player", 0, 0)
        Dim TreeNode50 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Media", 11, 11, New System.Windows.Forms.TreeNode() {TreeNode47, TreeNode48, TreeNode49})
        Dim TreeNode51 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("AVG", 0, 0)
        Dim TreeNode52 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("MalwareBytes", 0, 0)
        Dim TreeNode53 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Windows Defender", 0, 0)
        Dim TreeNode54 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Spybot S&D", -2, 0)
        Dim TreeNode55 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Antivirus", 12, 12, New System.Windows.Forms.TreeNode() {TreeNode51, TreeNode52, TreeNode53, TreeNode54})
        Dim TreeNode56 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("VS 2010", 0, 0)
        Dim TreeNode57 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("VS 2008", 0, 0)
        Dim TreeNode58 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("VS 2005", 0, 0)
        Dim TreeNode59 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Visual Studio", 13, 13, New System.Windows.Forms.TreeNode() {TreeNode56, TreeNode57, TreeNode58})
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblResults = New System.Windows.Forms.Label()
        Me.btnClean = New System.Windows.Forms.Button()
        Me.btnScan = New System.Windows.Forms.Button()
        Me.lvwTemps = New System.Windows.Forms.ListView()
        Me.colDirectory = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.files = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sizef = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.pgBrowsers = New System.Windows.Forms.TabPage()
        Me.tvwBrowsers = New System.Windows.Forms.TreeView()
        Me.pgUserSystem = New System.Windows.Forms.TabPage()
        Me.tvwUserSystem = New System.Windows.Forms.TreeView()
        Me.pgOther = New System.Windows.Forms.TabPage()
        Me.tvwOther = New System.Windows.Forms.TreeView()
        Me.progressScanning = New System.Windows.Forms.ProgressBar()
        Me.lblInformation = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Zv800ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TempToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebsightToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MakersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.pgBrowsers.SuspendLayout()
        Me.pgUserSystem.SuspendLayout()
        Me.pgOther.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.lblResults)
        Me.Panel1.Controls.Add(Me.btnClean)
        Me.Panel1.Controls.Add(Me.btnScan)
        Me.Panel1.Controls.Add(Me.lvwTemps)
        Me.Panel1.Controls.Add(Me.TabControl1)
        Me.Panel1.Controls.Add(Me.progressScanning)
        Me.Panel1.Location = New System.Drawing.Point(73, 58)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(754, 509)
        Me.Panel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(207, 449)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Path : "
        '
        'lblResults
        '
        Me.lblResults.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblResults.Location = New System.Drawing.Point(383, 465)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(260, 29)
        Me.lblResults.TabIndex = 9
        '
        'btnClean
        '
        Me.btnClean.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnClean.Location = New System.Drawing.Point(302, 471)
        Me.btnClean.Name = "btnClean"
        Me.btnClean.Size = New System.Drawing.Size(75, 23)
        Me.btnClean.TabIndex = 7
        Me.btnClean.Text = "&Clean"
        Me.btnClean.UseVisualStyleBackColor = True
        '
        'btnScan
        '
        Me.btnScan.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnScan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnScan.Location = New System.Drawing.Point(206, 471)
        Me.btnScan.Name = "btnScan"
        Me.btnScan.Size = New System.Drawing.Size(75, 23)
        Me.btnScan.TabIndex = 6
        Me.btnScan.Text = "&Scan"
        Me.btnScan.UseVisualStyleBackColor = True
        '
        'lvwTemps
        '
        Me.lvwTemps.AllowColumnReorder = True
        Me.lvwTemps.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvwTemps.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colDirectory, Me.files, Me.sizef})
        Me.lvwTemps.FullRowSelect = True
        Me.lvwTemps.GridLines = True
        Me.lvwTemps.HideSelection = False
        Me.lvwTemps.Location = New System.Drawing.Point(210, 75)
        Me.lvwTemps.MultiSelect = False
        Me.lvwTemps.Name = "lvwTemps"
        Me.lvwTemps.ShowItemToolTips = True
        Me.lvwTemps.Size = New System.Drawing.Size(533, 365)
        Me.lvwTemps.TabIndex = 5
        Me.lvwTemps.UseCompatibleStateImageBehavior = False
        Me.lvwTemps.View = System.Windows.Forms.View.Details
        '
        'colDirectory
        '
        Me.colDirectory.Text = "Directory"
        Me.colDirectory.Width = 329
        '
        'files
        '
        Me.files.Text = "Files"
        '
        'sizef
        '
        Me.sizef.Text = "Size"
        Me.sizef.Width = 51
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.pgBrowsers)
        Me.TabControl1.Controls.Add(Me.pgUserSystem)
        Me.TabControl1.Controls.Add(Me.pgOther)
        Me.TabControl1.Location = New System.Drawing.Point(3, 46)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(201, 394)
        Me.TabControl1.TabIndex = 3
        '
        'pgBrowsers
        '
        Me.pgBrowsers.Controls.Add(Me.tvwBrowsers)
        Me.pgBrowsers.Location = New System.Drawing.Point(4, 22)
        Me.pgBrowsers.Name = "pgBrowsers"
        Me.pgBrowsers.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.pgBrowsers.Size = New System.Drawing.Size(193, 368)
        Me.pgBrowsers.TabIndex = 0
        Me.pgBrowsers.Text = "Browsers"
        Me.pgBrowsers.UseVisualStyleBackColor = True
        '
        'tvwBrowsers
        '
        Me.tvwBrowsers.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tvwBrowsers.CheckBoxes = True
        Me.tvwBrowsers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tvwBrowsers.Location = New System.Drawing.Point(3, 3)
        Me.tvwBrowsers.Name = "tvwBrowsers"
        TreeNode1.ImageIndex = -2
        TreeNode1.Name = "Node0"
        TreeNode1.SelectedImageIndex = -2
        TreeNode1.Text = "Cookies"
        TreeNode2.ImageIndex = -2
        TreeNode2.Name = "Node1"
        TreeNode2.SelectedImageIndex = -2
        TreeNode2.Text = "Temporary Internet Files"
        TreeNode3.ImageIndex = -2
        TreeNode3.Name = "Node2"
        TreeNode3.SelectedImageIndex = -2
        TreeNode3.Text = "History"
        TreeNode4.ImageIndex = -2
        TreeNode4.Name = "Node3"
        TreeNode4.SelectedImageIndex = -2
        TreeNode4.Text = "Recently Typed URLs"
        TreeNode5.ImageIndex = -2
        TreeNode5.Name = "Node4"
        TreeNode5.SelectedImageIndex = -2
        TreeNode5.Text = "Index"
        TreeNode6.ImageIndex = 3
        TreeNode6.Name = "Node0"
        TreeNode6.SelectedImageIndex = 3
        TreeNode6.Text = "Internet Explorer"
        TreeNode7.Name = "Node0"
        TreeNode7.SelectedImageIndex = 0
        TreeNode7.Text = "Cookies"
        TreeNode8.Name = "Node1"
        TreeNode8.SelectedImageIndex = 0
        TreeNode8.Text = "Cache"
        TreeNode9.Name = "Node2"
        TreeNode9.SelectedImageIndex = 0
        TreeNode9.Text = "Internet History"
        TreeNode10.ImageIndex = 1
        TreeNode10.Name = "Node1"
        TreeNode10.SelectedImageIndex = 1
        TreeNode10.Text = "Google Chrome"
        TreeNode11.ImageIndex = 0
        TreeNode11.Name = "Node0"
        TreeNode11.SelectedImageIndex = 0
        TreeNode11.Text = "Cookies"
        TreeNode12.ImageIndex = 0
        TreeNode12.Name = "Node7"
        TreeNode12.SelectedImageIndex = 0
        TreeNode12.Text = "Download History"
        TreeNode13.ImageIndex = 0
        TreeNode13.Name = "Node8"
        TreeNode13.SelectedImageIndex = 0
        TreeNode13.Text = "Form History"
        TreeNode14.ImageIndex = 0
        TreeNode14.Name = "Node9"
        TreeNode14.SelectedImageIndex = 0
        TreeNode14.Text = "Cache"
        TreeNode15.ImageIndex = 0
        TreeNode15.Name = "Node10"
        TreeNode15.SelectedImageIndex = 0
        TreeNode15.Text = "Session Store"
        TreeNode16.ImageIndex = 2
        TreeNode16.Name = "Node2"
        TreeNode16.SelectedImageIndex = 2
        TreeNode16.Text = "Mozilla Firefox"
        TreeNode17.Name = "Node11"
        TreeNode17.SelectedImageIndex = 0
        TreeNode17.Text = "Cache"
        TreeNode18.ImageIndex = 0
        TreeNode18.Name = "Node14"
        TreeNode18.SelectedImageIndex = 0
        TreeNode18.Text = "History"
        TreeNode19.ImageIndex = 0
        TreeNode19.Name = "Node17"
        TreeNode19.SelectedImageIndex = 0
        TreeNode19.Text = "Webpage Previews"
        TreeNode20.ImageIndex = 0
        TreeNode20.Name = "Node5"
        TreeNode20.SelectedImageIndex = 0
        TreeNode20.Text = "Download History"
        TreeNode21.ImageIndex = 0
        TreeNode21.Name = "Node7"
        TreeNode21.SelectedImageIndex = 0
        TreeNode21.Text = "Last Session"
        TreeNode22.ImageIndex = 4
        TreeNode22.Name = "Node3"
        TreeNode22.SelectedImageIndex = 4
        TreeNode22.Text = "Safari"
        TreeNode23.ImageIndex = 0
        TreeNode23.Name = "Node1"
        TreeNode23.SelectedImageIndex = 0
        TreeNode23.Text = "Cache"
        TreeNode24.ImageIndex = 0
        TreeNode24.Name = "Node2"
        TreeNode24.SelectedImageKey = "blank_16x16.png"
        TreeNode24.Text = "History"
        TreeNode25.ImageIndex = 0
        TreeNode25.Name = "Node3"
        TreeNode25.SelectedImageIndex = 0
        TreeNode25.Text = "Cookies"
        TreeNode26.ImageIndex = 0
        TreeNode26.Name = "Node4"
        TreeNode26.SelectedImageIndex = 0
        TreeNode26.Text = "Website Icons"
        TreeNode27.ImageIndex = 0
        TreeNode27.Name = "Node8"
        TreeNode27.SelectedImageIndex = 0
        TreeNode27.Text = "Download History"
        TreeNode28.ImageIndex = 5
        TreeNode28.Name = "Node0"
        TreeNode28.SelectedImageIndex = 5
        TreeNode28.Text = "Opera"
        Me.tvwBrowsers.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode6, TreeNode10, TreeNode16, TreeNode22, TreeNode28})
        Me.tvwBrowsers.ShowLines = False
        Me.tvwBrowsers.ShowPlusMinus = False
        Me.tvwBrowsers.ShowRootLines = False
        Me.tvwBrowsers.Size = New System.Drawing.Size(187, 362)
        Me.tvwBrowsers.TabIndex = 0
        '
        'pgUserSystem
        '
        Me.pgUserSystem.Controls.Add(Me.tvwUserSystem)
        Me.pgUserSystem.Location = New System.Drawing.Point(4, 22)
        Me.pgUserSystem.Name = "pgUserSystem"
        Me.pgUserSystem.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.pgUserSystem.Size = New System.Drawing.Size(193, 368)
        Me.pgUserSystem.TabIndex = 1
        Me.pgUserSystem.Text = "User/System"
        Me.pgUserSystem.UseVisualStyleBackColor = True
        '
        'tvwUserSystem
        '
        Me.tvwUserSystem.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tvwUserSystem.CheckBoxes = True
        Me.tvwUserSystem.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tvwUserSystem.Location = New System.Drawing.Point(3, 3)
        Me.tvwUserSystem.Name = "tvwUserSystem"
        TreeNode29.ImageIndex = 0
        TreeNode29.Name = "Node1"
        TreeNode29.SelectedImageIndex = 0
        TreeNode29.Text = "Recent Documents"
        TreeNode30.ImageIndex = 0
        TreeNode30.Name = "Node3"
        TreeNode30.SelectedImageIndex = 0
        TreeNode30.Text = "Thumbnail Cache"
        TreeNode31.ImageIndex = 6
        TreeNode31.Name = "Node0"
        TreeNode31.SelectedImageIndex = 6
        TreeNode31.Text = "Windows Explorer"
        TreeNode32.ImageKey = "blank_16x16.png"
        TreeNode32.Name = "Node1"
        TreeNode32.SelectedImageIndex = 0
        TreeNode32.Text = "Windows Temp Files"
        TreeNode33.ImageIndex = 0
        TreeNode33.Name = "Node3"
        TreeNode33.SelectedImageIndex = 0
        TreeNode33.Text = "User Temp Files"
        TreeNode34.ImageIndex = 0
        TreeNode34.Name = "Node4"
        TreeNode34.SelectedImageIndex = 0
        TreeNode34.Text = "Memory Dumps"
        TreeNode35.ImageIndex = 0
        TreeNode35.Name = "Node5"
        TreeNode35.SelectedImageIndex = 0
        TreeNode35.Text = "ChkDsk File Fragments"
        TreeNode36.ImageIndex = 0
        TreeNode36.Name = "Node6"
        TreeNode36.SelectedImageIndex = 0
        TreeNode36.Text = "Windows Log Files"
        TreeNode37.ImageIndex = 0
        TreeNode37.Name = "Node8"
        TreeNode37.SelectedImageIndex = 0
        TreeNode37.Text = "Windows Error Reporting"
        TreeNode38.ImageKey = "system_16x16.png"
        TreeNode38.Name = "Node0"
        TreeNode38.SelectedImageIndex = 7
        TreeNode38.Text = "System"
        TreeNode39.ImageIndex = -2
        TreeNode39.Name = "Node1"
        TreeNode39.SelectedImageIndex = -2
        TreeNode39.Text = "Prefetch Data"
        TreeNode40.ImageIndex = 8
        TreeNode40.Name = "Node0"
        TreeNode40.SelectedImageIndex = 8
        TreeNode40.Text = "Advanced"
        Me.tvwUserSystem.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode31, TreeNode38, TreeNode40})
        Me.tvwUserSystem.ShowLines = False
        Me.tvwUserSystem.ShowPlusMinus = False
        Me.tvwUserSystem.ShowRootLines = False
        Me.tvwUserSystem.Size = New System.Drawing.Size(187, 362)
        Me.tvwUserSystem.TabIndex = 1
        '
        'pgOther
        '
        Me.pgOther.Controls.Add(Me.tvwOther)
        Me.pgOther.Location = New System.Drawing.Point(4, 22)
        Me.pgOther.Name = "pgOther"
        Me.pgOther.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.pgOther.Size = New System.Drawing.Size(193, 368)
        Me.pgOther.TabIndex = 2
        Me.pgOther.Text = "Other"
        Me.pgOther.UseVisualStyleBackColor = True
        '
        'tvwOther
        '
        Me.tvwOther.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tvwOther.CheckBoxes = True
        Me.tvwOther.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tvwOther.Location = New System.Drawing.Point(3, 3)
        Me.tvwOther.Name = "tvwOther"
        TreeNode41.Name = "Node1"
        TreeNode41.Text = "uTorrent"
        TreeNode42.Name = "Node2"
        TreeNode42.Text = "Java"
        TreeNode43.Name = "Node3"
        TreeNode43.Text = "FileZilla"
        TreeNode44.ImageIndex = 9
        TreeNode44.Name = "Node0"
        TreeNode44.SelectedImageIndex = 9
        TreeNode44.Text = "Internet Applications"
        TreeNode45.ImageIndex = 0
        TreeNode45.Name = "Node5"
        TreeNode45.SelectedImageIndex = 0
        TreeNode45.Text = "Paint.NET"
        TreeNode46.ImageIndex = 10
        TreeNode46.Name = "Node4"
        TreeNode46.SelectedImageIndex = 10
        TreeNode46.Text = "Miscellaneous Applications"
        TreeNode47.ImageIndex = 0
        TreeNode47.Name = "Node3"
        TreeNode47.SelectedImageKey = "blank_16x16.png"
        TreeNode47.Text = "Windows Media Player"
        TreeNode48.ImageIndex = 0
        TreeNode48.Name = "Node4"
        TreeNode48.SelectedImageIndex = 0
        TreeNode48.Text = "Quick Time Player"
        TreeNode49.ImageIndex = 0
        TreeNode49.Name = "Node5"
        TreeNode49.SelectedImageIndex = 0
        TreeNode49.Text = "Adobe Flash Player"
        TreeNode50.ImageIndex = 11
        TreeNode50.Name = "Node2"
        TreeNode50.SelectedImageIndex = 11
        TreeNode50.Text = "Media"
        TreeNode51.ImageIndex = 0
        TreeNode51.Name = "Node7"
        TreeNode51.SelectedImageIndex = 0
        TreeNode51.Text = "AVG"
        TreeNode52.ImageIndex = 0
        TreeNode52.Name = "Node8"
        TreeNode52.SelectedImageIndex = 0
        TreeNode52.Text = "MalwareBytes"
        TreeNode53.ImageIndex = 0
        TreeNode53.Name = "Node9"
        TreeNode53.SelectedImageIndex = 0
        TreeNode53.Text = "Windows Defender"
        TreeNode54.ImageIndex = -2
        TreeNode54.Name = "Node10"
        TreeNode54.SelectedImageIndex = 0
        TreeNode54.Text = "Spybot S&D"
        TreeNode55.ImageIndex = 12
        TreeNode55.Name = "Node6"
        TreeNode55.SelectedImageIndex = 12
        TreeNode55.Text = "Antivirus"
        TreeNode56.ImageIndex = 0
        TreeNode56.Name = "Node1"
        TreeNode56.SelectedImageIndex = 0
        TreeNode56.Text = "VS 2010"
        TreeNode57.ImageIndex = 0
        TreeNode57.Name = "Node2"
        TreeNode57.SelectedImageIndex = 0
        TreeNode57.Text = "VS 2008"
        TreeNode58.ImageIndex = 0
        TreeNode58.Name = "Node3"
        TreeNode58.SelectedImageIndex = 0
        TreeNode58.Text = "VS 2005"
        TreeNode59.ImageIndex = 13
        TreeNode59.Name = "Node0"
        TreeNode59.SelectedImageIndex = 13
        TreeNode59.Text = "Visual Studio"
        Me.tvwOther.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode44, TreeNode46, TreeNode50, TreeNode55, TreeNode59})
        Me.tvwOther.ShowLines = False
        Me.tvwOther.ShowPlusMinus = False
        Me.tvwOther.ShowRootLines = False
        Me.tvwOther.Size = New System.Drawing.Size(187, 362)
        Me.tvwOther.TabIndex = 2
        '
        'progressScanning
        '
        Me.progressScanning.Location = New System.Drawing.Point(206, 46)
        Me.progressScanning.Name = "progressScanning"
        Me.progressScanning.Size = New System.Drawing.Size(537, 23)
        Me.progressScanning.TabIndex = 1
        '
        'lblInformation
        '
        Me.lblInformation.AutoSize = True
        Me.lblInformation.BackColor = System.Drawing.Color.Transparent
        Me.lblInformation.ForeColor = System.Drawing.Color.Gray
        Me.lblInformation.Location = New System.Drawing.Point(20, 26)
        Me.lblInformation.Name = "lblInformation"
        Me.lblInformation.Size = New System.Drawing.Size(0, 13)
        Me.lblInformation.TabIndex = 8
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1, 144)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(69, 21)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "cleaner"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1, 171)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(69, 20)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "Start-Up"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.ListView1)
        Me.Panel2.Location = New System.Drawing.Point(409, 58)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(394, 446)
        Me.Panel2.TabIndex = 14
        '
        'ListView1
        '
        Me.ListView1.CheckBoxes = True
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(29, 16)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(713, 506)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(40, 40)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Zv800ToolStripMenuItem, Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.TempToolStripMenuItem, Me.ClearFolderToolStripMenuItem, Me.WebsightToolStripMenuItem, Me.MakersToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(2, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(841, 24)
        Me.MenuStrip1.TabIndex = 15
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Zv800ToolStripMenuItem
        '
        Me.Zv800ToolStripMenuItem.Name = "Zv800ToolStripMenuItem"
        Me.Zv800ToolStripMenuItem.Size = New System.Drawing.Size(48, 22)
        Me.Zv800ToolStripMenuItem.Text = "zv800"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogFilesToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 22)
        Me.FileToolStripMenuItem.Text = "file"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(42, 22)
        Me.HelpToolStripMenuItem.Text = "help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(50, 22)
        Me.AboutToolStripMenuItem.Text = "about"
        '
        'LogFilesToolStripMenuItem
        '
        Me.LogFilesToolStripMenuItem.Name = "LogFilesToolStripMenuItem"
        Me.LogFilesToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.LogFilesToolStripMenuItem.Text = "log files"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(671, 465)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "©2021 zv800"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(671, 481)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "©z2ck100"
        '
        'TempToolStripMenuItem
        '
        Me.TempToolStripMenuItem.Name = "TempToolStripMenuItem"
        Me.TempToolStripMenuItem.Size = New System.Drawing.Size(47, 22)
        Me.TempToolStripMenuItem.Text = "temp"
        '
        'ClearFolderToolStripMenuItem
        '
        Me.ClearFolderToolStripMenuItem.Name = "ClearFolderToolStripMenuItem"
        Me.ClearFolderToolStripMenuItem.Size = New System.Drawing.Size(78, 22)
        Me.ClearFolderToolStripMenuItem.Text = "clear folder"
        '
        'WebsightToolStripMenuItem
        '
        Me.WebsightToolStripMenuItem.Name = "WebsightToolStripMenuItem"
        Me.WebsightToolStripMenuItem.Size = New System.Drawing.Size(67, 22)
        Me.WebsightToolStripMenuItem.Text = "websight"
        '
        'MakersToolStripMenuItem
        '
        Me.MakersToolStripMenuItem.Name = "MakersToolStripMenuItem"
        Me.MakersToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.MakersToolStripMenuItem.Text = "makers"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(841, 569)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.lblInformation)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "RClean"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.pgBrowsers.ResumeLayout(False)
        Me.pgUserSystem.ResumeLayout(False)
        Me.pgOther.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents progressScanning As System.Windows.Forms.ProgressBar
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents pgBrowsers As System.Windows.Forms.TabPage
    Friend WithEvents tvwBrowsers As System.Windows.Forms.TreeView
    Friend WithEvents pgUserSystem As System.Windows.Forms.TabPage
    Friend WithEvents tvwUserSystem As System.Windows.Forms.TreeView
    Friend WithEvents pgOther As System.Windows.Forms.TabPage
    Friend WithEvents tvwOther As System.Windows.Forms.TreeView
    Friend WithEvents btnClean As System.Windows.Forms.Button
    Friend WithEvents btnScan As System.Windows.Forms.Button
    Friend WithEvents lvwTemps As System.Windows.Forms.ListView
    Friend WithEvents colDirectory As System.Windows.Forms.ColumnHeader
    Friend WithEvents files As System.Windows.Forms.ColumnHeader
    Friend WithEvents sizef As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblInformation As System.Windows.Forms.Label
    Friend WithEvents lblResults As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Zv800ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogFilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TempToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearFolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WebsightToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MakersToolStripMenuItem As ToolStripMenuItem
End Class
