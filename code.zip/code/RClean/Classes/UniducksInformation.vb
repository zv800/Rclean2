﻿'ACleaner - Temp file scanning and cleaning software
'Copyright (C) 2011  Ernest Jr
'
'This program is free software: you can redistribute it and/or modify
'it under the terms of the GNU General Public License as published by
'the Free Software Foundation, either version 3 of the License, or
'any later version.
'
'This program is distributed in the hope that it will be useful,
'but WITHOUT ANY WARRANTY; without even the implied warranty of
'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'GNU General Public License for more details.
'
'You should have received a copy of the GNU General Public License
'along with this program.  If not, see <http://www.gnu.org/licenses/>

Imports Microsoft.Win32
Imports System.Management

Public Class UniducksInformation

    Public Function GetComputerInformation() As String
        Return getOS() & ", " & getProcessor() & ", " & osb() & ", " & ram()
    End Function

    Private Function getOS() As String
        Return My.Computer.Info.OSFullName & getServicePack.ToString
    End Function

    Private Function getProcessor() As String
        Dim SoftwareKey As String = "HARDWARE\DESCRIPTION\System\CentralProcessor\0"
        Using rk As RegistryKey = Registry.LocalMachine.OpenSubKey(SoftwareKey)
            Dim propertiesKey As RegistryKey = Registry.LocalMachine.OpenSubKey(SoftwareKey, False)

            Dim name = propertiesKey.GetValue("ProcessorNameString")
            Return CStr(name)
            propertiesKey.Close()
        End Using
    End Function

    Private Function osb() As String
        If (Environment.Is64BitOperatingSystem) = True Then
            Return "OS 64 bits."
        Else
            Return "OS 32 bits."
        End If

    End Function
    Private Function ram() As String
        Return "RAM " & Math.Round((My.Computer.Info.TotalPhysicalMemory) / 1073741824).ToString() & " Go"
    End Function

   

    Private Declare Function GetVersionExA Lib "kernel32" (ByRef lpVersionInformation As OSVERSIONINFO) As Short
    Private Function getServicePack() As String
        Dim osinfo As OSVERSIONINFO
        Dim retvalue As Short
        osinfo.dwOSVersionInfoSize = 148
        retvalue = GetVersionExA(osinfo)
        If Len(osinfo.szCSDVersion) = 0 Then
            Return ("")
        Else
            Return " - " & (CStr(osinfo.szCSDVersion))
        End If
    End Function
    Private Structure OSVERSIONINFO
        Dim dwOSVersionInfoSize As Integer
        Dim dwMajorVersion As Integer
        Dim dwMinorVersion As Integer
        Dim dwBuildNumber As Integer
        Dim dwPlatformId As Integer
        <VBFixedString(128), _
          System.Runtime.InteropServices.MarshalAs _
               (System.Runtime.InteropServices.UnmanagedType.ByValTStr, _
            SizeConst:=128)> Dim szCSDVersion As String

    End Structure
End Class
